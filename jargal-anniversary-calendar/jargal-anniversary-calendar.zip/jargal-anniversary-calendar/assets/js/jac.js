jQuery(document).ready(function(){

jQuery("#post-wrapper .post-column:first-child article.sticky").before("<h3> « Anniversaire(s) du jour » </h3>");


});