<?php 

add_action( 'wp_ajax_prs_empty_all_slots', 'prs_empty_all_slots' );
add_action( 'wp_ajax_nopriv_prs_empty_all_slots', 'prs_empty_all_slots' );

function prs_empty_all_slots() {
	global $wpdb; // this is how you get access to the database

	$slots = $_POST['slots'];

	if($slots == 1){
    	$table_name = $wpdb->base_prefix.'prs_bookings';
    	$wpdb->query('TRUNCATE TABLE '.$table_name );
    	echo "All Slots Removed";
    }


	wp_die(); // this is required to terminate immediately and return a proper response
}