<?php
// create custom plugin settings menu
add_action('admin_menu', 'prs_plugin_create_menu');

function prs_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('Prayer Schedule Settings', 'Prayer Schedule', 'manage_options', 'prs_prayer_schedule_settings_page', 'prs_plugin_settings_page' , 'dashicons-bell', 25 );

	//call register settings function
	add_action( 'admin_init', 'register_prs_plugin_settings' );
}


function register_prs_plugin_settings() {
	//register our settings
	register_setting( 'prs-plugin-settings-group', 'starting_date' );
	register_setting( 'prs-plugin-settings-group', 'ending_date' );
	//register_setting( 'prs-plugin-settings-group', 'option_etc' );
}

function prs_plugin_settings_page() {
?>
<div class="wrap" style="padding: 10px 20px; background: #fff; ">
<h1>Prayer Schedule Settings</h1> <hr>

<form method="post" action="options.php">
    <?php settings_fields( 'prs-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'prs-plugin-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Start Date</th>
        <td><input type="text" name="starting_date" value="<?php echo esc_attr( get_option('starting_date') ); ?>" /><br><i>Date format to follow: YY-MM-DD </i></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">End Date</th>
        <td><input type="text" name="ending_date" value="<?php echo esc_attr( get_option('ending_date') ); ?>" /><br><i>Date format to follow: YY-MM-DD </i></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"> Slots</th>
        <td><input type="button" id="empty_slots" value="Empty Slots" class="button button-default" /></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php } ?>