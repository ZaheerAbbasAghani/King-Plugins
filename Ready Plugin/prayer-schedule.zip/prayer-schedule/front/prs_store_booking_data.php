<?php 

add_action( 'wp_ajax_prs_store_booking_data', 'prs_store_booking_data' );
add_action( 'wp_ajax_nopriv_prs_store_booking_data', 'prs_store_booking_data' );

function prs_store_booking_data() {
	global $wpdb; 
	$table_name = $wpdb->base_prefix.'prs_bookings';

	$user_name = $_POST['user_name'];
	$user_email = $_POST['user_email'];
	$slot = $_POST['slot'];
	$slot_date = $_POST['slot_date'];


	$query = "SELECT * FROM $table_name WHERE bDate='$slot_date' AND $slot=1";
	$query_results = $wpdb->get_results($query);
	if(count($query_results) == 0) {
		$rowResult=$wpdb->insert($table_name, array("bDate" => $slot_date, "$slot" => 1),array("%s","%d"));

		$to = "payouthconvention@gmail.com";
		$subject = "Booking enquiry created on ".get_bloginfo('name');
		$message = "<p> Name: <b>".$user_name."</b>  </p> <p> Email: ".$user_email."  </p><p> Time Slot: ".$slot." </p> <p> Date: ".date('d-m-Y', $slot_date)."  </p>";
		$headers = array('Content-Type: text/html; charset=UTF-8');

		wp_mail($to, $subject, $message, $headers);
		echo " Booking done Successfully.  \n";	
	}else{
		echo " Booking Already Exists.  \n";	
	}


	wp_die(); // this is required to terminate immediately and return a proper response
}