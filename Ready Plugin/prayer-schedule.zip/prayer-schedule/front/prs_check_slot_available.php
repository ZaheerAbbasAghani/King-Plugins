<?php 

add_action( 'wp_ajax_prs_check_slot_available', 'prs_check_slot_available' );
add_action( 'wp_ajax_nopriv_prs_check_slot_available', 'prs_check_slot_available' );

function prs_check_slot_available() {
	global $wpdb; // this is how you get access to the database
	$table_name = $wpdb->base_prefix.'prs_bookings';

	$date = strtotime($_POST['selected_date']);
	//$slot = $_POST['slot'];
	$query = "SELECT * FROM $table_name WHERE bDate='$date' ";
	$query_results = $wpdb->get_results($query);



	echo '<tr><td colspan="8" style="text-align:center;">';
		if($query_results[0]->breakfast == 1){
		 	echo '<button class="slot" disabled> Breakfast </button>';
		}else{
			echo '<button data-attr="breakfast" date-attr="'.$date.'" class="slot" > Breakfast </button>';
		}

		if($query_results[0]->lunch == 1){
		 	echo '<button class="slot" disabled> Lunch </button>';
		}else{
			echo '<button data-attr="lunch" date-attr="'.$date.'" class="slot" > Lunch </button>';
		}

		if($query_results[0]->supper == 1){
		 	echo '<button class="slot" disabled> Supper </button>';
		}else{
			echo '<button data-attr="supper" date-attr="'.$date.'" class="slot" > Supper </button>';
		}
	echo '</td> </tr>';
	


	wp_die(); // this is required to terminate immediately and return a proper response
}