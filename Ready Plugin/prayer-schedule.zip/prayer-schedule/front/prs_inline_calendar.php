<?php 

function prs_inline_calendar_process($calendar){

$calendar = "";

$calendar .= '<div id="prs_datepicker"></div>';

return $calendar;
}
add_shortcode("calendar", 'prs_inline_calendar_process');