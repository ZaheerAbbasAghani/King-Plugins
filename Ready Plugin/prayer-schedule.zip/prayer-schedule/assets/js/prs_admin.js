jQuery(document).ready(function(){


// Booking in action

jQuery(document).on("click","#empty_slots", function(e){
	e.preventDefault();
	if(confirm("Are you sure you want to remove?")){
		var data = {
			'action': 'prs_empty_all_slots',
			'slots': 1,
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(prs_ajax_object.ajax_url, data, function(response) {
			alert(response);
			location.reload();
		});
	}else{
		return false;
	}
});






});