jQuery(document).ready(function(){

// Calendar In action
var datePicker = jQuery("div#prs_datepicker");

var dateToday = new Date();
var nextYear = dateToday.getFullYear() + 1;
datePicker.datepicker({
    changeMonth: false,
    minDate: new Date(prs_ajax_object.start_date),
    maxDate: new Date(prs_ajax_object.ending_date),
    changeYear: false,
    inline: true,
    firstDay: 7,
}).change(function(e){

	var selected_date = jQuery(this).val();

	var data = {
		'action': 'prs_check_slot_available',
		'selected_date': selected_date
	};

	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(prs_ajax_object.ajax_url, data, function(response) {
		setTimeout(function(){   
			datePicker
			.find('.ui-datepicker-current-day')
			.parent()
			.after(response);
	    });
	});
});


// Popup in action

jQuery(document).on("click",".slot", function(){

	var slot = jQuery(this).attr("data-attr");
	var slot_date = jQuery(this).attr("date-attr");
	//alert(slot);

		Swal.fire({
	  		title: "Add Booking <hr>", 
	  	 	html: "<div class='formWrapper'> <form method='post' action='' id='slot_management'> <input type='text' id='user_name' placeholder='Enter your name' required/>  <input type='email' id='user_email' placeholder='Enter your email' required/> <input type='hidden' id='slot' value='"+slot+"' > <input type='hidden' id='slot_date' value='"+slot_date+"' ><input type='submit' value='Submit'></form> </div>",
	 		showCancelButton: false, allowOutsideClick: false,
	 		showConfirmButton: false,
	 		showCloseButton: true,
		});

});


// Booking in action

jQuery(document).on("submit","#slot_management", function(e){
	e.preventDefault();

	jQuery(this).find("input[type='submit']").attr("disabled", true);

	var user_name = jQuery("#user_name").val();
	var user_email = jQuery("#user_email").val();
	var slot = jQuery("#slot").val();
	var slot_date = jQuery("#slot_date").val();

	var data = {
		'action': 'prs_store_booking_data',
		'user_name': user_name,
		'user_email':user_email,
		'slot':slot,
		'slot_date':slot_date,
	};

	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(prs_ajax_object.ajax_url, data, function(response) {
		alert(response);
		location.reload();
	});
});






});