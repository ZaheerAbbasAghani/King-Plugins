<?php
/*
Plugin Name: Prayer Schedule
Plugin URI: https://www.fiverr.com/zaheerabbasagha
Description: This plugin shows three time slots per day (listed as "Breakfast", "Lunch", and "Supper").  This will run on your WordPress website. It will provide the ability for a person to select and sign up for one of the available time slots. When they do, that time slot will show that it is taken and no one else can select that time slot. When they sign up they will provide their Name and email address which is sent to your email address
Version: 1.0
Author: Zaheer Abbas Aghani
Author URI: https://profiles.wordpress.org/zaheer01/
License: GPLv3 or later
Text Domain: prayer-schedule
Domain Path: /languages
*/

defined("ABSPATH") or die("No direct access!");
class PrayerSchedule {

function __construct() {
	add_action('init', array($this, 'prs_start_from_here'));
	add_action('wp_enqueue_scripts', array($this, 'prs_enqueue_script_front'));
	add_action('admin_enqueue_scripts', array($this, 'prs_enqueue_script_dashboard'));
	
	add_action('init', array($this, 'prs_create_table'));
	
}



function prs_start_from_here() {
	require_once plugin_dir_path(__FILE__) . 'front/prs_inline_calendar.php';
	require_once plugin_dir_path(__FILE__) . 'front/prs_check_slot_available.php';
	require_once plugin_dir_path(__FILE__) . 'front/prs_store_booking_data.php';
	
	require_once plugin_dir_path(__FILE__).'back/prayer_schedule_settings_page.php';
	require_once plugin_dir_path(__FILE__).'back/prs_empty_all_slots.php';
}

// Enqueue Style and Scripts

function prs_enqueue_script_front() {
	//Style & Script

	wp_enqueue_script( 'jquery-ui-datepicker');
	wp_enqueue_style( 'jquery-ui', 'https://code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css' );
	//wp_enqueue_script('jquery-ui-core');

	wp_enqueue_style('prs-sweetalert2', 'https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.min.css','11.1.9','all');

	wp_enqueue_style('prs-style', plugins_url('assets/css/prs.css', __FILE__),'1.0.0','all');

	wp_enqueue_script('prs-sweetalert2', 'https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.all.min.js',array('jquery'),'11.1.9', true);
	wp_enqueue_script('prs-script', plugins_url('assets/js/prs.js', __FILE__),array('jquery','jquery-ui-core'),'1.0.0', true);

	wp_localize_script( 'prs-script', 'prs_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ),'start_date' => get_option('starting_date'),'ending_date' => get_option('ending_date'), ) );

}

function prs_enqueue_script_dashboard($hook) {

	if($hook != 'toplevel_page_prs_prayer_schedule_settings_page')
		return 0;
		
		wp_enqueue_script('prs-script-admin', plugins_url('assets/js/prs_admin.js', __FILE__),array('jquery','jquery-ui-core'),'1.0.0', true);

		wp_localize_script( 'prs-script-admin', 'prs_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	


}

function prs_create_table(){

    global $wpdb;
    $table_name = $wpdb->base_prefix.'prs_bookings';
    $query = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) );
    if ( ! $wpdb->get_var( $query ) == $table_name ) {

        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
          id mediumint(255) NOT NULL AUTO_INCREMENT,
          bDate varchar(50) NOT NULL,
          breakfast TINYINT(1) NOT NULL,
          lunch TINYINT(1) NOT NULL,
          supper TINYINT(1) NOT NULL,
          PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

    }

}




} // class ends

// CHECK WETHER CLASS EXISTS OR NOT.

if (class_exists('PrayerSchedule')) {
	$obj = new PrayerSchedule();
}